package com.khesya.idn.news_10

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
